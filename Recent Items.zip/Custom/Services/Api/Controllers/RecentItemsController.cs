﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using SitefinityWebApp.Custom.Services.Models;
using Telerik.Sitefinity.Dashboard.Data;
using Telerik.Sitefinity.News.Model;
using Telerik.Sitefinity.Security.Model;
using Telerik.Sitefinity.Security;

namespace SitefinityWebApp.Custom.Services.Api.Controllers
{
    public class RecentItemsController : ApiController
    {
        private DashboardManager _manager = null;
        
        public class ItemCounts
        {
            public string FullName = String.Empty;
            public string ContentType = String.Empty;
            public int ContentCount = 0;
        }

        public DashboardManager Manager
        {
            get
            {
                return _manager ??
                    (_manager = DashboardManager.GetManager());
            }
        }

        // GET api/<controller>
        public IEnumerable<ItemCounts> Get()
        {
            var myCollection = new List<RecentItemsModel>();
            var myCounts = new List<ItemCounts>();
            try
            {
                this.Manager.GetDashboardLogEntries()
                    .Where(r => r.Timestamp > DateTime.UtcNow.AddMonths(-1))
                    .OrderByDescending(r => r.UserId)
                    .ThenBy(r => r.ItemType)
                    .ToList()
                    .ForEach(r => myCollection.Add(new RecentItemsModel(r)));
            }
            catch { Exception ex; }

            myCounts.AddRange(SetCountsByUserAndItemType(myCollection));
            return myCounts;
        }

        // GET api/<controller>/5
        public IEnumerable<RecentItemsModel> Get(string id)
        {
            var myCollection = new List<RecentItemsModel>();
            UserManager userManager = UserManager.GetManager();
            User user = userManager.GetUser(id);

            try
            {
                this.Manager.GetDashboardLogEntries()
                    .Where(r => r.Timestamp > DateTime.UtcNow.AddMonths(-1) &&
                        r.UserId == user.Id)
                    .OrderByDescending(r => r.UserId)
                    .ThenBy(r => r.ItemType)
                    .ToList()
                    .ForEach(r => myCollection.Add(new RecentItemsModel(r)));
            }
            catch { Exception ex; }

            return myCollection;
        }

        private IEnumerable<ItemCounts> SetCountsByUserAndItemType(List<RecentItemsModel> items)
        {
            var myCounts = new List<ItemCounts>();
            int itemTypeCount = 0;
            Guid userId = new Guid();
            string itemType = String.Empty;
            string userFullName = String.Empty;
            ItemCounts currentItem = null;
            foreach(var item in items)
            {
                currentItem = new ItemCounts();

                //initial loop - nothing set yet
                if (userId == Guid.Empty && String.IsNullOrEmpty(itemType))
                {
                    userId = item.UserId;
                    itemType = item.ItemType;
                    userFullName = item.UserFullName;
                    itemTypeCount = 1;
                }
                //same user and same item type, increment count
                else if (userId == item.UserId && itemType == item.ItemType)
                {
                    itemTypeCount = itemTypeCount + 1;
                }
                //new user or new content type, add to collection and reset values
                else if (userId != item.UserId || itemType != item.ItemType)
                {
                    currentItem.FullName = userFullName;
                    currentItem.ContentType = itemType;
                    currentItem.ContentCount = itemTypeCount;
                    myCounts.Add(currentItem);

                    //reset values
                    userId = item.UserId;
                    itemType = item.ItemType;
                    userFullName = item.UserFullName;
                    itemTypeCount = 1;
                }
            }

            currentItem = new ItemCounts();
            currentItem.FullName = userFullName;
            currentItem.ContentType = itemType;
            currentItem.ContentCount = itemTypeCount;
            myCounts.Add(currentItem);

            return myCounts;
        }

        //How many news items were published in the last month
        //this.Manager.GetDashboardLogEntries()
        //    .Where(e => e.ItemType == typeof(NewsItem).FullName &&
        //        e.Timestamp > DateTime.UtcNow.AddMonths(-1)).Count();

        //How many items are currently in Awaiting Approval
        //this.Manager.GetDashboardLogEntries()
        //    .Where(e => e.Status == "Awaiting Approval").Count();

        //How many items were published by each news author
        //this.Manager.GetDashboardLogEntries()
        //    .Where(e => e.ItemType == typeof(NewsItem).FullName)
        //    .GroupBy(e => e.UserId)
        //    .Select(g => { return new { Key = g.Key, Value = g.Count() }; });

        //this.Manager.GetDataItems(announcementsType)
        //        .Where(a => a.Status == ContentLifecycleStatus.Live && a.FieldValue<string[]>("Audience").Contains("all"))
        //        .OrderByDescending(o => o.DateCreated)
        //        .ToList()
        //        .ForEach(a => myCollection.Add(new AnnouncementsModel(a)));

        

        //// POST api/<controller>
        //public void Post([FromBody]string value)
        //{
        //}

        //// PUT api/<controller>/5
        //public void Put(int id, [FromBody]string value)
        //{
        //}

        //// DELETE api/<controller>/5
        //public void Delete(int id)
        //{
        //}
    }
}